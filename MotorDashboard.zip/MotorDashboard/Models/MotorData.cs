﻿using System.Windows.Media;

namespace MotorDashboard.Models
{
    public class MotorData
    {
        // System Status
        public string p1_1_RunState { get; set; } = "1";
        public int i1_1_RunState { get; set; } = 1; // 0=Red, 1=Green, 2=Yellow

        public string p1_2_FaultStatus { get; set; } = "0";
        public int i1_2_FaultStatus { get; set; } = 0;

        public string p1_3_ReadyState { get; set; } = "1";
        public int i1_3_ReadyState { get; set; } = 1;

        public string p1_4_Enabled { get; set; } = "1";
        public int i1_4_Enabled { get; set; } = 1;

        public string p1_5_RunState { get; set; } = "1";
        public int i1_5_RunState { get; set; } = 1;

        public string p1_6_FaultStatus { get; set; } = "0";
        public int i1_6_FaultStatus { get; set; } = 0;

        // Operation Mode
        public string p2_1_OpMode { get; set; } = "AUTO";
        public int i2_1_OpMode { get; set; } = 1;

        public string p2_2_Direction { get; set; } = "FWD";
        public int i2_2_Direction { get; set; } = 1;

        public string p2_3_CtrlMode { get; set; } = "REMOTE";
        public int i2_3_CtrlMode { get; set; } = 1;

        public string p2_4_JogMode { get; set; } = "0";
        public int i2_4_JogMode { get; set; } = 0;

        public string p2_5_OpMode { get; set; } = "AUTO";
        public int i2_5_OpMode { get; set; } = 1;

        public string p2_6_Direction { get; set; } = "FWD";
        public int i2_6_Direction { get; set; } = 1;

        // Commands
        public string p3_1_Start { get; set; } = "";
        public int i3_1_Start { get; set; } = 1;

        public string p3_2_Stop { get; set; } = "";
        public int i3_2_Stop { get; set; } = 0;

        public string p3_3_Reset { get; set; } = "";
        public int i3_3_Reset { get; set; } = 0;

        public string p3_4_JogFwd { get; set; } = "";
        public int i3_4_JogFwd { get; set; } = 0;

        public string p3_5_Start { get; set; } = "";
        public int i3_5_Start { get; set; } = 1;

        public string p3_6_Stop { get; set; } = "";
        public int i3_6_Stop { get; set; } = 0;

        public string p3_7_Reset { get; set; } = "";
        public int i3_7_Reset { get; set; } = 0;

        public string p4_1_EStop { get; set; } = "";
        public int i4_1_EStop { get; set; } = 0;

        public string p4_2_FaultAck { get; set; } = "";
        public int i4_2_FaultAck { get; set; } = 0;

        public string p4_3_JogRev { get; set; } = "";
        public int i4_3_JogRev { get; set; } = 0;

        public string p4_4_Home { get; set; } = "";
        public int i4_4_Home { get; set; } = 0;

        public string p4_5_EStop { get; set; } = "";
        public int i4_5_EStop { get; set; } = 0;

        public string p4_6_FaultAck { get; set; } = "";
        public int i4_6_FaultAck { get; set; } = 0;

        public string p4_7_JogRev { get; set; } = "";
        public int i4_7_JogRev { get; set; } = 0;

        // Safety Limits
        public string p5_1_Overload { get; set; } = "";
        public int i5_1_Overload { get; set; } = 0;

        public string p5_2_OverTemp { get; set; } = "";
        public int i5_2_OverTemp { get; set; } = 2;

        public string p5_3_OverVolt { get; set; } = "";
        public int i5_3_OverVolt { get; set; } = 0;

        public string p5_4_UnderVolt { get; set; } = "";
        public int i5_4_UnderVolt { get; set; } = 0;

        public string p6_1_OverSpeed { get; set; } = "";
        public int i6_1_OverSpeed { get; set; } = 0;

        public string p6_2_CommErr { get; set; } = "";
        public int i6_2_CommErr { get; set; } = 0;

        public string p6_3_EncoderErr { get; set; } = "";
        public int i6_3_EncoderErr { get; set; } = 0;

        public string p6_4_HWFault { get; set; } = "";
        public int i6_4_HWFault { get; set; } = 0;

        // System Info
        public string p7_1_Uptime { get; set; } = "156.3h";
        public int i7_1_Uptime { get; set; } = 1;

        public string p7_2_Starts { get; set; } = "245";
        public int i7_2_Starts { get; set; } = 1;

        public string p7_3_FWVer { get; set; } = "v2.1.5";
        public int i7_3_FWVer { get; set; } = 1;

        public string p7_4_Serial { get; set; } = "MTR-8472";
        public int i7_4_Serial { get; set; } = 1;

        public string p7_5_Uptime { get; set; } = "156.3h";
        public int i7_5_Uptime { get; set; } = 1;

        public string p8_1_PwrOn { get; set; } = "89.7h";
        public int i8_1_PwrOn { get; set; } = 1;

        public string p8_2_LastFault { get; set; } = "None";
        public int i8_2_LastFault { get; set; } = 1;

        public string p8_3_HWVer { get; set; } = "Rev C";
        public int i8_3_HWVer { get; set; } = 1;

        public string p8_4_DevID { get; set; } = "001";
        public int i8_4_DevID { get; set; } = 1;

        public string p8_5_PwrOn { get; set; } = "89.7h";
        public int i8_5_PwrOn { get; set; } = 1;

        // Diagnostics
        public string p9_1_SelfTest { get; set; } = "PASS";
        public int i9_1_SelfTest { get; set; } = 1;

        public string p9_2_Calibration { get; set; } = "OK";
        public int i9_2_Calibration { get; set; } = 1;

        public string p9_3_Memory { get; set; } = "PASS";
        public int i9_3_Memory { get; set; } = 1;

        public string p9_4_Watchdog { get; set; } = "ACTIVE";
        public int i9_4_Watchdog { get; set; } = 1;

        public string p10_1_IOTest { get; set; } = "PASS";
        public int i10_1_IOTest { get; set; } = 1;

        public string p10_2_CommTest { get; set; } = "PASS";
        public int i10_2_CommTest { get; set; } = 1;

        public string p10_3_SensorTest { get; set; } = "PASS";
        public int i10_3_SensorTest { get; set; } = 1;

        public string p10_4_SafetyTest { get; set; } = "PASS";
        public int i10_4_SafetyTest { get; set; } = 1;
    }
}