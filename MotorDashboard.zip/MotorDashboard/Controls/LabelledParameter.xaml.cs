﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace MotorDashboard.Controls
{
    public partial class LabelledParameter : UserControl
    {
        public LabelledParameter()
        {
            InitializeComponent();
        }

        // Label text
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register(
                nameof(Label),
                typeof(string),
                typeof(LabelledParameter),
                new PropertyMetadata(string.Empty));

        public string Label
        {
            get => (string)GetValue(LabelProperty);
            set => SetValue(LabelProperty, value);
        }

        // Value text
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register(
                nameof(Value),
                typeof(string),
                typeof(LabelledParameter),
                new PropertyMetadata(string.Empty));

        public string Value
        {
            get => (string)GetValue(ValueProperty);
            set => SetValue(ValueProperty, value);
        }

        // Indicator color (Brush)
        public static readonly DependencyProperty IndicatorBrushProperty =
            DependencyProperty.Register(
                nameof(IndicatorBrush),
                typeof(Brush),
                typeof(LabelledParameter),
                new PropertyMetadata(Brushes.Gray));

        public Brush IndicatorBrush
        {
            get => (Brush)GetValue(IndicatorBrushProperty);
            set => SetValue(IndicatorBrushProperty, value);
        }

        // Whether this row is indicator-only (no value)
        public static readonly DependencyProperty IsIndicatorOnlyProperty =
            DependencyProperty.Register(
                nameof(IsIndicatorOnly),
                typeof(bool),
                typeof(LabelledParameter),
                new PropertyMetadata(false));

        public bool IsIndicatorOnly
        {
            get => (bool)GetValue(IsIndicatorOnlyProperty);
            set => SetValue(IsIndicatorOnlyProperty, value);
        }
    }
}
