﻿using System.Windows.Controls;
using MotorDashboard.Models;

namespace MotorDashboard.Views
{
    public partial class RealTimePage : Page
    {
        public MotorData MotorData = new MotorData();

        public RealTimePage()
        {
            InitializeComponent();

            // Set the data context to our MotorData instance
            this.DataContext = MotorData;
        }

        // Method to update individual parameter
        public void UpdateParameter(string parameterName, string value, int indicator)
        {
            // This method will be used when you have real-time data
            // For now, it's a placeholder for future implementation

            // Example usage:
            // UpdateParameter("p1_1_RunState", "1", 1);
            // UpdateParameter("p1_2_FaultStatus", "0", 0);

            // You'll implement the actual mapping logic here based on your data structure
        }

        // Method to update from CSV/array data
        public void UpdateFromDataArray(string[] dataArray)
        {
            // This is where you'll map your CSV/array data to the variables
            // Example structure of dataArray:
            // dataArray[0] = "1"  // p1_1_RunState value
            // dataArray[1] = "1"  // i1_1_RunState value  
            // dataArray[2] = "0"  // p1_2_FaultStatus value
            // dataArray[3] = "0"  // i1_2_FaultStatus value
            // etc...

            // Future implementation:
            // MotorData.p1_1_RunState = dataArray[0];
            // MotorData.i1_1_RunState = int.Parse(dataArray[1]);
            // MotorData.p1_2_FaultStatus = dataArray[2];
            // MotorData.i1_2_FaultStatus = int.Parse(dataArray[3]);
            // Continue for all parameters...
        }
    }
}