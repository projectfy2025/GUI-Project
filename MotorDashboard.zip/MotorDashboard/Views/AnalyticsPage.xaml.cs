﻿using System.Windows.Controls;

namespace MotorDashboard.Views
{
    public partial class AnalyticsPage : Page
    {
        public AnalyticsPage()
        {
            InitializeComponent();
        }
    }
}
