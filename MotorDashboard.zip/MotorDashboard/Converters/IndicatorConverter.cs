﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace MotorDashboard.Converters
{
    public class IndicatorValueToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int indicatorValue)
            {
                return indicatorValue switch
                {
                    0 => Brushes.Red,
                    1 => Brushes.LimeGreen,
                    2 => Brushes.Yellow,
                    _ => Brushes.Gray
                };
            }
            return Brushes.Gray;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}