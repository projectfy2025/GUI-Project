﻿using System;
using System.IO.Ports;

class Program
{
    static SerialPort serialPort;

    static void Main(string[] args)
    {
        Console.WriteLine("=== UART Serial Reader ===\n");

        Console.WriteLine("Available Ports:");
        foreach (string port in SerialPort.GetPortNames())
        {
            Console.WriteLine("  " + port);
        }

        Console.Write("\nEnter COM Port (e.g., COM3): ");
        string selectedPort = Console.ReadLine();

        serialPort = new SerialPort(selectedPort, 115200, Parity.None, 8, StopBits.One);
        serialPort.DataReceived += SerialDataReceived;
        serialPort.Open();

        Console.WriteLine($"\nListening on {selectedPort}...\nPress ENTER to exit.");
        Console.ReadLine();

        serialPort.Close();
    }

    static void SerialDataReceived(object sender, SerialDataReceivedEventArgs e)
    {
        try
        {
            string data = serialPort.ReadLine();   // read one line terminated with '\n'
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] {data}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }
}
